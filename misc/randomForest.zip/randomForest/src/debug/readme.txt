predictDescriptor noTrees noActiveVars maxDepth minSampCount maxCategories print importance trainfilename testfilename
e.g. predictDescriptor 100 4 30 30 25 1 train.data test.data

nActiveVariables - recomended sqrt of dim
minSampCount - dont split a node if less

Computed the data on the VisPC 13. Issue with transfering the .txt files over. Had to do it via fs.pollefeys. 