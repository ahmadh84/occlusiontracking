totalEpe = [67.6782  54.6450  71.0100  59.7534 57.5642]
barh(totalEpe, 'w');
set(gca,'YTickLabel',{'BA', 'TV', 'HS', 'FL', 'Ours'})
xlabel('Total Epe')
