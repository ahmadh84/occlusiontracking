# counts as an error when the prediction is not dont track, otherwise its ok
import sys

inputFileName = sys.argv[1]
prediction = open('results_' + inputFileName, 'r')

count = 0
err = 0
for gtLine in open(inputFileName, 'r'):
    p = prediction.readline()
    #print [int(p[0]), int(gtLine[0])]
    
    gt = int(gtLine[0])
    pre = int(p[0])
    if ((gt == 5) & (pre != 5)):
        err = err + 1
    elif ((gt != 5) & (pre == 5)):
        err = err + 1
    
    count = count + 1
    
print 'Test Error = ' + str( float(err) /count*100)  + '%'