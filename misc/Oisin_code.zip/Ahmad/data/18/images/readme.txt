for 18preEpe and 18Flepe the max error shown is 30 pixels (corresponding to white)

in 18distance the max distance shown is 15 (white)